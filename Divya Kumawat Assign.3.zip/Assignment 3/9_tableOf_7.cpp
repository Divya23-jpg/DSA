#include<iostream>
using namespace std;
int main(){
     
   int n=7;

   for(int i=1;i<=10;i++){
     cout<<"7*"<<i<<"="<<7*i;
     cout<<endl;
    
     cout<<endl;
   }
    return 0;
}