#include<iostream>
using namespace std;
int main(){
     
    int a;
    int b;
    cout<<"Enter 1st Number::";
    cin>>a;
    cout<<"Enter 2nd Number::";
    cin>>b;
    int c = a+b;
    cout<<"The sum of given two numbers is:: "<< c<<endl;

    return 0;
}